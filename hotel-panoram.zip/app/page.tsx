"use client"

import Image from "next/image"
import { Phone, ChevronDown } from "lucide-react"

import { Button } from "@/components/ui/button"
import { useLanguage } from "@/contexts/language-context"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function Home() {
  const { t, language, setLanguage } = useLanguage()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold tracking-tight">{t("hotel.name")}</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <a href="#about" className="text-sm font-medium transition-colors hover:text-primary">
              {t("nav.about")}
            </a>
            <a href="#rooms" className="text-sm font-medium transition-colors hover:text-primary">
              {t("nav.rooms")}
            </a>
            <a href="#amenities" className="text-sm font-medium transition-colors hover:text-primary">
              {t("nav.amenities")}
            </a>
            <a href="#culture" className="text-sm font-medium transition-colors hover:text-primary">
              {t("nav.culture")}
            </a>
            <a href="#contact" className="text-sm font-medium transition-colors hover:text-primary">
              {t("nav.contact")}
            </a>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-1 text-sm font-medium transition-colors hover:text-primary">
                  {t("nav.language")}
                  <ChevronDown className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setLanguage("en")} className={language === "en" ? "bg-muted" : ""}>
                  {t("language.english")}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage("ka")} className={language === "ka" ? "bg-muted" : ""}>
                  {t("language.georgian")}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
          <Button asChild className="hidden md:flex">
            <a href="#contact">{t("button.bookNow")}</a>
          </Button>
          <Button variant="outline" size="icon" className="md:hidden">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
            <span className="sr-only">Toggle menu</span>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <section className="relative">
          <div className="relative h-[70vh] w-full overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-NsaxP4XVFNSlTFLWiiV7zjsPdk2k6j.png"
              alt="Panoramic view of Sighnaghi"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-black/40" />
            <div className="container absolute inset-0 flex flex-col items-center justify-center text-center text-white">
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">{t("hero.welcome")}</h1>
              <p className="mt-4 max-w-2xl text-lg sm:text-xl">{t("hero.subtitle")}</p>
              <Button asChild size="lg" className="mt-8">
                <a href="#contact">{t("button.bookNow")}</a>
              </Button>
            </div>
          </div>
        </section>

        <section id="about" className="py-16 md:py-24">
          <div className="container">
            <div className="grid gap-8 md:grid-cols-2 md:gap-12">
              <div>
                <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">{t("about.title")}</h2>
                <p className="mt-4 text-lg text-muted-foreground">{t("about.p1")}</p>
                <p className="mt-4 text-lg text-muted-foreground">{t("about.p2")}</p>
              </div>
              <div className="relative h-[300px] md:h-full overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-mimvNvK20FqRap8WaoL1ICIlhnfNdJ.png"
                  alt="Sighnaghi town view"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="rooms" className="bg-muted py-16 md:py-24">
          <div className="container">
            <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl mb-12">{t("rooms.title")}</h2>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="bg-white rounded-lg overflow-hidden shadow-md">
                <div className="relative h-64">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-BLzxjW0OgTpwEwjDuiEsSoUOaFzhgw.png"
                    alt="Standard Room"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold">{t("rooms.standard.title")}</h3>
                  <p className="mt-2 text-muted-foreground">{t("rooms.standard.description")}</p>
                  <Button asChild variant="outline" className="mt-4 w-full">
                    <a href="#contact">{t("button.bookNow")}</a>
                  </Button>
                </div>
              </div>
              <div className="bg-white rounded-lg overflow-hidden shadow-md">
                <div className="relative h-64">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-BLzxjW0OgTpwEwjDuiEsSoUOaFzhgw.png"
                    alt="Family Room"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold">{t("rooms.family.title")}</h3>
                  <p className="mt-2 text-muted-foreground">{t("rooms.family.description")}</p>
                  <Button asChild variant="outline" className="mt-4 w-full">
                    <a href="#contact">{t("button.bookNow")}</a>
                  </Button>
                </div>
              </div>
              <div className="bg-white rounded-lg overflow-hidden shadow-md">
                <div className="relative h-64">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-jXlwX7UZH3PJxjiEmoNFPPs0B2As2Z.png"
                    alt="Private Bathroom"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold">{t("rooms.bathroom.title")}</h3>
                  <p className="mt-2 text-muted-foreground">{t("rooms.bathroom.description")}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="amenities" className="py-16 md:py-24">
          <div className="container">
            <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl mb-12">{t("amenities.title")}</h2>
            <div className="grid gap-8 md:grid-cols-2">
              <div className="relative h-[400px] overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Ks02wptPLH1kftmtcbt5FdcqJ2nin6.png"
                  alt="Swimming Pool"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="text-2xl font-bold">{t("amenities.pool.title")}</h3>
                <p className="mt-4 text-lg text-muted-foreground">{t("amenities.pool.description")}</p>
                <ul className="mt-6 space-y-2">
                  <li className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-5 w-5 text-primary"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    {t("amenities.wifi")}
                  </li>
                  <li className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-5 w-5 text-primary"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    {t("amenities.breakfast")}
                  </li>
                  <li className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-5 w-5 text-primary"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    {t("amenities.terrace")}
                  </li>
                  <li className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-5 w-5 text-primary"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    {t("amenities.wine")}
                  </li>
                </ul>
              </div>
            </div>
            <div className="mt-12 grid gap-8 md:grid-cols-2">
              <div className="order-2 md:order-1 flex flex-col justify-center">
                <h3 className="text-2xl font-bold">{t("amenities.relax.title")}</h3>
                <p className="mt-4 text-lg text-muted-foreground">{t("amenities.relax.p1")}</p>
                <p className="mt-4 text-lg text-muted-foreground">{t("amenities.relax.p2")}</p>
              </div>
              <div className="order-1 md:order-2 relative h-[400px] overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-c0bu6CBgEziqlwTW1SxuFp90eSQp6Z.png"
                  alt="Pool with View"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="culture" className="bg-muted py-16 md:py-24">
          <div className="container">
            <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl mb-12">{t("culture.title")}</h2>
            <div className="grid gap-8 md:grid-cols-2">
              <div className="relative h-[400px] overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7m5WGmSlfuLNM1os1OeCb0xPXhObMp.png"
                  alt="Georgian Cuisine"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="text-2xl font-bold">{t("culture.cuisine.title")}</h3>
                <p className="mt-4 text-lg text-muted-foreground">{t("culture.cuisine.p1")}</p>
                <p className="mt-4 text-lg text-muted-foreground">{t("culture.cuisine.p2")}</p>
              </div>
            </div>
            <div className="mt-12">
              <div className="bg-white rounded-lg p-8 shadow-md">
                <h3 className="text-2xl font-bold mb-4">{t("culture.wine.title")}</h3>
                <p className="text-lg text-muted-foreground">{t("culture.wine.p1")}</p>
                <p className="mt-4 text-lg text-muted-foreground">{t("culture.wine.p2")}</p>
                <div className="mt-6 grid gap-4 md:grid-cols-3">
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-bold">{t("culture.feasts.title")}</h4>
                    <p className="mt-2">{t("culture.feasts.description")}</p>
                  </div>
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-bold">{t("culture.singing.title")}</h4>
                    <p className="mt-2">{t("culture.singing.description")}</p>
                  </div>
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-bold">{t("culture.crafts.title")}</h4>
                    <p className="mt-2">{t("culture.crafts.description")}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="contact" className="py-16 md:py-24">
          <div className="container">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">{t("contact.title")}</h2>
              <p className="mt-4 text-lg text-muted-foreground">{t("contact.subtitle")}</p>
            </div>
            <div className="mx-auto mt-12 max-w-md">
              <div className="rounded-lg bg-white p-8 shadow-lg">
                <div className="flex flex-col items-center text-center">
                  <Phone className="h-10 w-10 text-primary" />
                  <h3 className="mt-4 text-xl font-bold">{t("contact.call.title")}</h3>
                  <p className="mt-2 text-muted-foreground">{t("contact.call.subtitle")}</p>
                  <Button asChild size="lg" className="mt-6 w-full">
                    <a href="tel:+995123456789">+995 123 456 789</a>
                  </Button>
                  <p className="mt-4 text-sm text-muted-foreground">{t("contact.languages")}</p>
                </div>
                <div className="mt-8 border-t pt-8">
                  <h4 className="font-semibold">{t("contact.address.title")}</h4>
                  <p className="mt-2 text-muted-foreground">
                    {t("contact.address.line1")}
                    <br />
                    {t("contact.address.line2")}
                    <br />
                    {t("contact.address.line3")}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t bg-muted py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} {t("hotel.name")}. {t("footer.rights")}
          </p>
          <div className="flex gap-4">
            <a href="#about" className="text-sm text-muted-foreground hover:text-primary">
              {t("nav.about")}
            </a>
            <a href="#rooms" className="text-sm text-muted-foreground hover:text-primary">
              {t("nav.rooms")}
            </a>
            <a href="#amenities" className="text-sm text-muted-foreground hover:text-primary">
              {t("nav.amenities")}
            </a>
            <a href="#culture" className="text-sm text-muted-foreground hover:text-primary">
              {t("nav.culture")}
            </a>
            <a href="#contact" className="text-sm text-muted-foreground hover:text-primary">
              {t("nav.contact")}
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
