"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

type Language = "en" | "ka"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    // Header
    "hotel.name": "Hotel Panoram",
    "nav.about": "About",
    "nav.rooms": "Rooms",
    "nav.amenities": "Amenities",
    "nav.culture": "Georgian Culture",
    "nav.contact": "Contact",
    "nav.language": "Language",
    "language.english": "English",
    "language.georgian": "Georgian",
    "button.bookNow": "Book Now",

    // Hero
    "hero.welcome": "Welcome to Hotel Panoram",
    "hero.subtitle": "Experience the warmth of Georgian hospitality in the heart of Sighnaghi",

    // About
    "about.title": "About Hotel Panoram",
    "about.p1":
      "Nestled in the picturesque town of Sighnaghi, Hotel Panoram offers a warm, family-friendly atmosphere with breathtaking views of the Alazani Valley and the Caucasus Mountains. Our hotel combines traditional Georgian hospitality with modern comforts to ensure your stay is memorable and relaxing.",
    "about.p2":
      'Whether you\'re exploring the cobblestone streets of Sighnaghi, known as the "City of Love," or venturing into the renowned Kakheti wine region, Hotel Panoram provides the perfect base for your Georgian adventure.',

    // Rooms
    "rooms.title": "Our Comfortable Rooms",
    "rooms.standard.title": "Standard Room",
    "rooms.standard.description": "Cozy and comfortable room with all essential amenities for a relaxing stay.",
    "rooms.family.title": "Family Room",
    "rooms.family.description": "Spacious room perfect for families, with additional beds and space for children.",
    "rooms.bathroom.title": "Modern Bathrooms",
    "rooms.bathroom.description": "All rooms feature clean, modern private bathrooms with essential amenities.",

    // Amenities
    "amenities.title": "Hotel Amenities",
    "amenities.pool.title": "Swimming Pool with a View",
    "amenities.pool.description":
      "Enjoy our stunning infinity pool overlooking the breathtaking Alazani Valley. The perfect spot to relax after a day of exploring Sighnaghi and the surrounding wine country.",
    "amenities.wifi": "Free Wi-Fi throughout the hotel",
    "amenities.breakfast": "Traditional Georgian breakfast",
    "amenities.terrace": "Terrace with panoramic views",
    "amenities.wine": "Wine tasting experiences",
    "amenities.relax.title": "Relax and Unwind",
    "amenities.relax.p1":
      "Our pool area offers the perfect setting to soak in the sun and enjoy the spectacular views of the surrounding landscape. Lounge chairs and shade structures ensure your comfort throughout the day.",
    "amenities.relax.p2":
      "The hotel's unique location provides guests with unforgettable sunsets over the Alazani Valley, creating magical moments for families and couples alike.",

    // Culture
    "culture.title": "Experience Georgian Culture",
    "culture.cuisine.title": "Traditional Georgian Cuisine",
    "culture.cuisine.p1":
      "Georgia is famous for its unique and delicious cuisine. Try the iconic khachapuri (cheese-filled bread), khinkali (dumplings), and various meat and vegetable dishes seasoned with traditional spices.",
    "culture.cuisine.p2":
      "At Hotel Panoram, we can arrange authentic Georgian cooking classes and dining experiences for our guests, allowing you to take a taste of Georgia back home with you.",
    "culture.wine.title": "The Wine Country of Kakheti",
    "culture.wine.p1":
      "Sighnaghi is located in the heart of Georgia's premier wine region, Kakheti. Georgia has an 8,000-year-old winemaking tradition, recognized as the oldest in the world. The traditional method of making wine in clay vessels called qvevri is on UNESCO's Intangible Cultural Heritage list.",
    "culture.wine.p2":
      "From Hotel Panoram, you can easily visit local wineries, participate in wine tastings, and learn about the ancient Georgian winemaking process. Our staff can arrange wine tours to suit your preferences, from small family wineries to larger estates.",
    "culture.feasts.title": "Traditional Feasts",
    "culture.feasts.description": "Experience a Georgian supra (feast) with toasts, songs, and abundant food",
    "culture.singing.title": "Polyphonic Singing",
    "culture.singing.description": "Georgia's UNESCO-recognized traditional music is a must-hear experience",
    "culture.crafts.title": "Local Crafts",
    "culture.crafts.description": "Discover traditional carpets, ceramics, and woodwork in Sighnaghi's shops",

    // Contact
    "contact.title": "Book Your Stay",
    "contact.subtitle":
      "Ready to experience the beauty of Sighnaghi and the comfort of Hotel Panoram? Contact us directly to book your stay.",
    "contact.call.title": "Call Us to Book",
    "contact.call.subtitle": "Our friendly staff is ready to assist you",
    "contact.languages": "We speak Georgian, English, and Russian",
    "contact.address.title": "Hotel Address:",
    "contact.address.line1": "Hotel Panoram",
    "contact.address.line2": "Sighnaghi, Kakheti Region",
    "contact.address.line3": "Georgia",

    // Footer
    "footer.rights": "All rights reserved.",
  },
  ka: {
    // Header
    "hotel.name": "სასტუმრო პანორამი",
    "nav.about": "ჩვენს შესახებ",
    "nav.rooms": "ოთახები",
    "nav.amenities": "სერვისები",
    "nav.culture": "ქართული კულტურა",
    "nav.contact": "კონტაქტი",
    "nav.language": "ენა",
    "language.english": "ინგლისური",
    "language.georgian": "ქართული",
    "button.bookNow": "დაჯავშნა",

    // Hero
    "hero.welcome": "მოგესალმებით სასტუმრო პანორამში",
    "hero.subtitle": "იგრძენით ქართული სტუმართმოყვარეობის სითბო სიღნაღის გულში",

    // About
    "about.title": "სასტუმრო პანორამის შესახებ",
    "about.p1":
      "სასტუმრო პანორამი მდებარეობს პიქტურესკულ ქალაქ სიღნაღში და გთავაზობთ თბილ, ოჯახურ ატმოსფეროს ალაზნის ველისა და კავკასიონის მთების შესანიშნავი ხედებით. ჩვენი სასტუმრო აერთიანებს ტრადიციულ ქართულ სტუმართმოყვარეობას თანამედროვე კომფორტთან, რათა თქვენი დასვენება იყოს დაუვიწყარი და რელაქსირებული.",
    "about.p2":
      "იქნება ეს სიღნაღის ქვაფენილიანი ქუჩების დათვალიერება, რომელიც ცნობილია როგორც „სიყვარულის ქალაქი“, თუ ცნობილ კახეთის ღვინის რეგიონში მოგზაურობა, სასტუმრო პანორამი წარმოადგენს იდეალურ ბაზას თქვენი ქართული თავგადასავლისთვის.",

    // Rooms
    "rooms.title": "ჩვენი კომფორტული ოთახები",
    "rooms.standard.title": "სტანდარტული ოთახი",
    "rooms.standard.description": "მყუდრო და კომფორტული ოთახი ყველა საჭირო საშუალებით დასასვენებლად.",
    "rooms.family.title": "საოჯახო ოთახი",
    "rooms.family.description": "ფართო ოთახი იდეალურია ოჯახებისთვის, დამატებითი საწოლებით და სივრცით ბავშვებისთვის.",
    "rooms.bathroom.title": "თანამედროვე სააბაზანოები",
    "rooms.bathroom.description": "ყველა ოთახს აქვს სუფთა, თანამედროვე კერძო სააბაზანო ყველა საჭირო საშუალებით.",

    // Amenities
    "amenities.title": "სასტუმროს სერვისები",
    "amenities.pool.title": "საცურაო აუზი ხედით",
    "amenities.pool.description":
      "ისიამოვნეთ ჩვენი შთამბეჭდავი აუზით, რომელიც გადაჰყურებს ალაზნის ველს. იდეალური ადგილი დასასვენებლად სიღნაღისა და მიმდებარე ღვინის ქვეყნის დათვალიერების შემდეგ.",
    "amenities.wifi": "უფასო Wi-Fi მთელ სასტუმროში",
    "amenities.breakfast": "ტრადიციული ქართული საუზმე",
    "amenities.terrace": "ტერასა პანორამული ხედებით",
    "amenities.wine": "ღვინის დეგუსტაციის გამოცდილება",
    "amenities.relax.title": "დაისვენეთ და განიტვირთეთ",
    "amenities.relax.p1":
      "ჩვენი აუზის ტერიტორია გთავაზობთ იდეალურ გარემოს მზის აბაზანების მისაღებად და გარშემო ლანდშაფტის შესანიშნავი ხედებით სარგებლობისთვის. სალონჯე სკამები და ჩრდილის სტრუქტურები უზრუნველყოფს თქვენს კომფორტს მთელი დღის განმავლობაში.",
    "amenities.relax.p2":
      "სასტუმროს უნიკალური მდებარეობა სტუმრებს სთავაზობს დაუვიწყარ მზის ჩასვლას ალაზნის ველზე, რაც ქმნის ჯადოსნურ მომენტებს ოჯახებისა და წყვილებისთვის.",

    // Culture
    "culture.title": "გაიცანით ქართული კულტურა",
    "culture.cuisine.title": "ტრადიციული ქართული სამზარეულო",
    "culture.cuisine.p1":
      "საქართველო ცნობილია თავისი უნიკალური და გემრიელი სამზარეულოთი. სცადეთ იკონური ხაჭაპური (ყველით სავსე პური), ხინკალი (ცომის გუფთები) და სხვადასხვა ხორცისა და ბოსტნეულის კერძები, შეზავებული ტრადიციული სანელებლებით.",
    "culture.cuisine.p2":
      "სასტუმრო პანორამში ჩვენ შეგვიძლია მოვაწყოთ ავთენტური ქართული სამზარეულოს გაკვეთილები და სადილის გამოცდილება ჩვენი სტუმრებისთვის, რაც საშუალებას მოგცემთ წაიღოთ საქართველოს გემო სახლში.",
    "culture.wine.title": "კახეთის ღვინის ქვეყანა",
    "culture.wine.p1":
      "სიღნაღი მდებარეობს საქართველოს პრემიერ ღვინის რეგიონის, კახეთის გულში. საქართველოს აქვს 8,000 წლიანი მეღვინეობის ტრადიცია, აღიარებული როგორც უძველესი მსოფლიოში. ღვინის დამზადების ტრადიციული მეთოდი თიხის ჭურჭელში, რომელსაც ქვევრი ეწოდება, შეტანილია UNESCO-ს არამატერიალური კულტურული მემკვიდრეობის სიაში.",
    "culture.wine.p2":
      "სასტუმრო პანორამიდან შეგიძლიათ ადვილად ეწვიოთ ადგილობრივ მარნებს, მიიღოთ მონაწილეობა ღვინის დეგუსტაციაში და შეისწავლოთ ღვინის დამზადების უძველესი ქართული პროცესი. ჩვენს პერსონალს შეუძლია მოაწყოს ღვინის ტურები თქვენი პრეფერენციების შესაბამისად, პატარა საოჯახო მარნებიდან დიდ მამულებამდე.",
    "culture.feasts.title": "ტრადიციული ნადიმები",
    "culture.feasts.description": "გამოცადეთ ქართული სუფრა სადღეგრძელოებით, სიმღერებით და უხვი საჭმლით",
    "culture.singing.title": "პოლიფონიური სიმღერა",
    "culture.singing.description": "საქართველოს UNESCO-ს მიერ აღიარებული ტრადიციული მუსიკა აუცილებლად მოსასმენია",
    "culture.crafts.title": "ადგილობრივი ხელნაკეთობები",
    "culture.crafts.description": "აღმოაჩინეთ ტრადიციული ხალიჩები, კერამიკა და ხის ნაკეთობები სიღნაღის მაღაზიებში",

    // Contact
    "contact.title": "დაჯავშნეთ თქვენი დარჩენა",
    "contact.subtitle":
      "მზად ხართ გამოცადოთ სიღნაღის სილამაზე და სასტუმრო პანორამის კომფორტი? დაგვიკავშირდით პირდაპირ თქვენი დარჩენის დასაჯავშნად.",
    "contact.call.title": "დაგვირეკეთ დასაჯავშნად",
    "contact.call.subtitle": "ჩვენი მეგობრული პერსონალი მზადაა დაგეხმაროთ",
    "contact.languages": "ჩვენ ვსაუბრობთ ქართულად, ინგლისურად და რუსულად",
    "contact.address.title": "სასტუმროს მისამართი:",
    "contact.address.line1": "სასტუმრო პანორამი",
    "contact.address.line2": "სიღნაღი, კახეთის რეგიონი",
    "contact.address.line3": "საქართველო",

    // Footer
    "footer.rights": "ყველა უფლება დაცულია.",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>("en")

  const t = (key: string): string => {
    return translations[language][key as keyof (typeof translations)[typeof language]] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
